
<?php $__env->startSection('style'); ?>
<style>
    .titlesParent .title__input:not(:first-child){
        display: none;
     
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">

                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">Xidmətlər</h4>
                            <button type="button"
                                onclick="unSet()"   class="btn btn-primary " data-bs-toggle="modal" data-bs-target="#partners_modal">Əlavə et</button>
                        </div>
                        <div class="card-body">
                            <table class="table table-nowrap">
                                <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Başlıq</th>
                                    <th scope="col">Foto</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <th scope="row"><a href="#" class="fw-semibold">#<?php echo e($partner->id); ?></a></th>
                                        <td><?php echo e($partner->translate('az')->title); ?></td>
                                        <td> <img src="<?php echo e($partner->image); ?>" width="50" height="50"> </td>
                                        <td><?php echo e($partner->status==1?' Aktiv ':'Passiv'); ?></td>
                                        <td>
                                            <div class="flex-wrap gap-3 hstack">

                                                    <button type="button"
                                                            data-bs-toggle="modal" data-bs-target="#partners_modal"
                                                            class="btn btn-ghost-info waves-effect waves-light shadow-none" onclick="formEditButton('<?php echo e($partner->id); ?>')"><i class="ri-edit-2-fill"></i></button>

                                            <form action="<?php echo e(route('service.destroy',$partner->id)); ?>" method="post">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="from_edit btn btn-ghost-danger waves-effect waves-light shadow-none"><i class="ri-delete-bin-line"></i></button>

                                            </form>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Default Modals -->





                <div id="partners_modal" class="modal fade" tabindex="-1" aria-labelledby="partners_modalLabel" aria-hidden="true" style="display: none;">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="partners_modalLabel">Xidmət Əlavə Et</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"> </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('service.store')); ?>" id="partner_form" method="post"  enctype='multipart/form-data'>
                                   <?php echo csrf_field(); ?>
                              
                                   <div class="row mb-3">
                                    <div class="custom__tab">
                                        <header>
                                         <ul class="nav nav-pills">
                                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <li onclick="setTab('titleInput<?php echo e($item->code); ?>',this)" class="nav-item">
                                                 <label for="titleInput<?php echo e($item->code); ?>" class="nav-link <?php echo e($key==0?'active':''); ?>" >Başlıq_<?php echo e($item->code); ?></label>
                                             </li>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </ul>
                                        </header>
                                        <div class="titlesParent">
                                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div id="titleInput<?php echo e($item->code); ?>" class="title__input">
                                        
                                            <input type="text" class="form-control "  placeholder="title <?php echo e($item->code); ?>" name="title:<?php echo e($item->code); ?>">  
                                          <textarea name="description:<?php echo e($item->code); ?>"  class="form-control mt-3"  cols="30" rows="10"><?php echo e($item->code); ?></textarea>
                                       
                                        </div>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                     </div>



                                </div>
                                
                                    
                                    <div class="row mb-3">
                                        <div class="col-lg-3">
                                            <label for="foto" class="form-label">Foto</label>
                                        </div>
                                        <div class="col-lg-9 d-flex">

                                            <img id="update_photo"/>
                                                <input class="form-control" name="file" type="file" id="foto">

                                        </div>
                                    </div>

                                  

                                    <div class="row mb-3">
                                        <div class="col-lg-3">
                                            <label for="titleInput" class="form-label">Slug</label>
                                        </div>
                                        <div class="col-lg-9">
                                            <input type="text" class="form-control" id="titleInput" placeholder="Slug" name="slug">
                                        </div>
                                    </div>
                                    <div class="form-check form-check-secondary mb-3">
                                       
                                        <input id="checkbox" name="status" type="checkbox" value="1">
                                        <label class="form-check-label" for="formCheck7">
                                           Status
                                        </label>
                                    </div>




                                </form>
                           </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary " id="submit_button" form="partner_form">Save Changes</button>
                            </div>

                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        // tab function

        function setTab(params,argument) {
            $('.title__input').css("display", "none");
            $('#'+params).css("display", "block")
            $('.nav-link').removeClass( 'active');
            $(argument).children('label').addClass( 'active');
        }
      const action =   $("#partner_form").attr('action')
      const title_form =  $('#partners_modalLabel').text()
        function unSet(){
            $("#partner_form").attr('action',action)
            $("#hidden__").remove()
            $('#partners_modalLabel').text(title_form)
            $('#update_photo').removeAttr('src')

            $('#titleInput').val('')
            $('#update_photo').css({'width':'0','height':'0'})

            $('#type_form').val('0')
            $('#foto').val('')
        }
        ;
       function formEditButton(id_) {
        $('#checkbox').prop("checked", false)
           $("#partner_form").attr('action','http://127.0.0.1:8000/service/'+id_)
           $("#partner_form").append( `<input type="hidden" name="_method" value="PUT" id="hidden__">`)
           $('#partners_modalLabel').text('Xidməti yenilə')
           $.ajax({
               type: "GET",
               url: 'service/'+id_,
                // serializes the form's elements.
               success: function(data)
               {
                   $('#titleInput').val(data.title)
                   $('#titleInput').val(data.slug)
                   $('#update_photo').css({'width':'80px','height':'80px'})
                   $('#update_photo').attr('src','/'+data.image)
                 
                  
           
                   $('.titlesParent').html('')
                   $('.nav-link').removeClass( 'active');
          
          $('.nav-pills .nav-item:first-child .nav-link').addClass( 'active')
      
          if (data.status=='1') {
            $('#checkbox').prop("checked", true);
          }
          
                   data.translations.forEach(item => {
                  let custom_input=  $("<div/>").addClass('title__input').attr('id','titleInput'+item.locale)
                   $('.titlesParent').append(custom_input.append($("<input/>").addClass('form-control ').attr({ "name": 'title:'+item.locale,'value':item.title})))
                   $('.titlesParent').append(custom_input.append($('<textarea/>').addClass('form-control mt-3').attr({"name":'description:'+item.locale,"cols":"30", "rows":"10"}).val(item.description)))
                });
          }
           });
       }











    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\eqoEcommerce\resources\views/back/service/index.blade.php ENDPATH**/ ?>