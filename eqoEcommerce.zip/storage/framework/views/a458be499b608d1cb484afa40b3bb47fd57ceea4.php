

<?php $__env->startSection('content'); ?>
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">

                 <form action="<?php echo e(route('about.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <div class="card-header align-items-center d-flex">
                            <label for="titleAbout">Başlıq: &nbsp</label>
                            <div class="card-title mb-0 flex-grow-1">
                                <input type="text" class="form-control" value="<?php echo e($about->title ?? ''); ?>" id="titleAbout"
                                    placeholder="title" name="title" style="width: 300px">
                            </div>

                            <div>
                                <button type="submit" class="btn btn-primary"><i class="ri-edit-2-fill"></i></button>
                            </div>
                        </div>
                        <div class="card-body">


                            <div class="d-flex">
                                <label for="editor">Mətn: &nbsp;</label>
                                <textarea id="editor" name="text">

                                    <?php echo e($about->text ?? ''); ?>

                                </textarea>
                            </div>

                            <div class="IMG d-flex mt-2">
                                <label for="foto" class="form-label">Foto: &nbsp </label>
                                <input class="form-control" name="file" type="file" id="foto"
                                    style="width:400px">
                                <img src="<?php echo e($about->image ?? ''); ?>" alt="" width="100" height="90">
                            </div>
                        </div>
                    </div>
                 </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/36.0.0/classic/ckeditor.js"></script>

    <script>
        ClassicEditor
            .create(document.querySelector('#editor'))
            .then(editor => {
                console.log(editor);
            })
            .catch(error => {
                console.error(error);
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\eqoEcommerce\resources\views/back/about/index.blade.php ENDPATH**/ ?>