<!-- JS
============================================ -->
<!--jquery min js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/jquery.magnific-popup.min.js"></script>
<!--jquery countdown min js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="<?php echo e(asset('themeplate')); ?>/assets/js/main.js"></script><?php /**PATH C:\Users\User\Desktop\eqoEcommerce\resources\views/front/layouts/script.blade.php ENDPATH**/ ?>