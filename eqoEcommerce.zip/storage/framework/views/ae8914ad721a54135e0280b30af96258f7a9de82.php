 <!-- JAVASCRIPT -->
 <script src="<?php echo e(asset('admin-panel')); ?>/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="<?php echo e(asset('admin-panel')); ?>/assets/libs/simplebar/simplebar.min.js"></script>
 <script src="<?php echo e(asset('admin-panel')); ?>/assets/libs/node-waves/waves.min.js"></script>
 <script src="<?php echo e(asset('admin-panel')); ?>/assets/libs/feather-icons/feather.min.js"></script>
 <script src="<?php echo e(asset('admin-panel')); ?>/assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
 <script src="<?php echo e(asset('admin-panel')); ?>/assets/js/plugins.js"></script>

 <!-- apexcharts -->
 <script src="<?php echo e(asset('admin-panel')); ?>/assets/libs/apexcharts/apexcharts.min.js"></script>

 <!-- projects js -->
 <script src="<?php echo e(asset('admin-panel')); ?>/assets/js/pages/dashboard-projects.init.js"></script>

 <!-- App js -->
 <script src="<?php echo e(asset('admin-panel')); ?>/assets/js/app.js"></script>

 <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
 @jquery

 @toastr_js

 @toastr_render

 <script>

     <?php if(count($errors) > 0): ?>

         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             toastr.error("<?php echo e($error); ?>");

         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     <?php endif; ?>

 </script><?php /**PATH C:\Users\User\Desktop\eqoEcommerce\resources\views/back/layouts/script.blade.php ENDPATH**/ ?>